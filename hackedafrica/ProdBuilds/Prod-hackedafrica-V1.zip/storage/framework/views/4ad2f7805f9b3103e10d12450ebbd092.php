<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />

    <!-- Styles -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>



<body class="bg-gray-800 text-gray-100 min-h-screen">
    <main class="flex justify-center items-center w-full">
        <div class="container mx-auto px-4 py-8 max-w-5xl md:max-w-7xl">
            <!-- App Name Section -->
            <header class="text-center mb-12">
                <h1 class="text-5xl font-bold text-yellow-400 font-mono">Who Hacked Africa</h1>
                <p class="text-xl mt-2 text-gray-400">Tracking Cybersecurity Incidents Across the Continent</p>
            </header>

            <!-- Cybersecurity Resources Section -->
            <section class="mb-12">
                <h2 class="text-2xl font-bold text-yellow-400 mb-4">Cybersecurity Resources</h2>
                <div class="bg-gray-800 rounded-lg p-6">
                    <p class="mb-4">Stay informed and protected with these essential cybersecurity resources:</p>
                    <ul class="list-disc list-inside space-y-2 text-gray-300">
                        <li>African Union Cybersecurity Expert Group (AUCSEG) Guidelines</li>
                        <li>National Computer Security Incident Response Teams (CSIRTs) Contacts</li>
                        <li>Africa Cybersecurity Resource Centre for Excellence (ACERCE)</li>
                        <li>Internet Society's African Regional Bureau Cybersecurity Program</li>
                    </ul>
                    <a href="#"
                        class="inline-block mt-4 px-4 py-2 bg-yellow-500 text-gray-900 rounded hover:bg-yellow-400 transition-colors">
                        Learn More
                    </a>
                </div>
            </section>

            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('main-feed');

$__html = app('livewire')->mount($__name, $__params, 'lw-725214530-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

        </div>
    </main>

    <footer class="py-16 text-center text-sm text-black dark:text-white/70">
        Laravel v<?php echo e(Illuminate\Foundation\Application::VERSION); ?> (PHP v<?php echo e(PHP_VERSION); ?>)
    </footer>
</body>

</html><?php /**PATH /home/charles/code/WhoHackedAfrica/hackedafrica/resources/views/welcome.blade.php ENDPATH**/ ?>